package Mapping;

public class NodeMath {
	private int nodeListSize;
	
	public NodeMath(int size, int nodeListSize) {
		this.nodeListSize = nodeListSize;
	}
	
	public boolean nodeOnEdge_Left(int nodePosition) {
		if(nodePosition % (int) Math.sqrt(nodeListSize) == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean nodeOnEdge_Right(int nodePosition) {
		if(nodePosition % (int) Math.sqrt(nodeListSize) == ((int) Math.sqrt(nodeListSize) - 1)) {
			return true;
		}
		else {
			return false;
		}
	}

	
	public boolean willNodeExist_Right(int nodePosition) {
		if((nodePosition + 1) < nodeListSize) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean willNodeExist_Left(int nodePostion) {
		if((nodePostion - 1) >= 0) {
			return true;
		}else {
			return false;
		}
	}
	
	
	public boolean willNodeExist_Top(int nodePosition) {
		if(nodePosition - (int) Math.sqrt(nodeListSize) > 0) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean willNodeExist_Bottom(int nodePostion) {
		if(nodePostion + (int) Math.sqrt((nodeListSize)) < nodeListSize) {
			return true;
		}else {
			return false;
		}
	}
}
