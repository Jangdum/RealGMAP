package Mapping;

public enum Colors {
	WHITE(),
	GRAY(),
	BLACK();
}
