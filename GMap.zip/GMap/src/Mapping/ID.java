package Mapping;

public enum ID {
	source(),
	edit(),
	target();
}
