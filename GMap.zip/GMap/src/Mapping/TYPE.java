package Mapping;

public enum TYPE {
	Solid(),
	Edit(),
	nonSolid();
}
 